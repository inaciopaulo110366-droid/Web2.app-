import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { signInWithPopup, signOut, onAuthStateChanged } from 'firebase/auth';
import type { User } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  Download,
  Globe,
  Layers,
  Loader2,
  LogOut,
  Plus,
  Search,
  SlidersHorizontal,
  Smartphone,
  X,
} from 'lucide-react';
import { AppEditorPanel } from './components/AppEditorPanel';
import type { EditorTab } from './components/AppEditorPanel';
import { DevicePreview } from './components/DevicePreview';
import { ErrorBoundary } from './components/ErrorBoundary';
import { LandingAuthView } from './components/LandingAuthView';
import { OperationType, auth, db, googleProvider, handleFirestoreError } from './firebase';
import type {
  AppProject,
  AppRevision,
  CandidateIcon,
  ExportFormat,
  UrlInspectionResult,
} from './types';
import {
  buildGeneratedFallbackIcon,
  imageSourceToPngDataUrl,
  sanitizePackageName,
} from './utils/iconHelper';

type MobileNavTab = 'apps' | 'editor' | 'preview' | 'exportar';

function normalizeUrlForSave(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) return 'https://example.com';
  const withProto = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  return withProto.slice(0, 500);
}

function normalizeHex(raw: string, fallback = '#2563EB'): string {
  const trimmed = (raw || '').trim();
  return /^#[0-9a-fA-F]{6}$/.test(trimmed) ? trimmed.toUpperCase() : fallback;
}

function normalizeAppDefaults(raw: Partial<AppProject>): AppProject {
  return {
    ...(raw as AppProject),
    splashAnimation: raw.splashAnimation || 'zoom',
    lockMobileViewport: raw.lockMobileViewport ?? true,
    disableZoom: raw.disableZoom ?? true,
    openExternalApps: raw.openExternalApps ?? true,
    permCamera: raw.permCamera ?? true,
    permMicrophone: raw.permMicrophone ?? true,
    permLocation: raw.permLocation ?? false,
    permFiles: raw.permFiles ?? true,
    permBiometrics: raw.permBiometrics ?? false,
  };
}

function WorkspaceApp() {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const [apps, setApps] = useState<AppProject[]>([]);
  const [appsLoading, setAppsLoading] = useState(true);
  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);
  const [draft, setDraft] = useState<AppProject | null>(null);
  const [revisions, setRevisions] = useState<AppRevision[]>([]);
  const [candidateIcons, setCandidateIcons] = useState<CandidateIcon[]>([]);

  const [searchQuery, setSearchQuery] = useState('');
  const [editorTab, setEditorTab] = useState<EditorTab>('geral');
  const [mobileTab, setMobileTab] = useState<MobileNavTab>('editor');

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newSiteUrl, setNewSiteUrl] = useState('');
  const [isCreatingApp, setIsCreatingApp] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);

  const [isSaving, setIsSaving] = useState(false);
  const [isInspecting, setIsInspecting] = useState(false);
  const [exportingFormat, setExportingFormat] = useState<ExportFormat | null>(null);
  const [saveFeedback, setSaveFeedback] = useState<string | null>(null);
  const [inspectMessage, setInspectMessage] = useState<string | null>(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  const autoSaveTimerRef = useRef<number | null>(null);

  const syncRemoteConfig = useCallback(async (appData: AppProject) => {
    try {
      await fetch(`/api/sync-config/${appData.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(appData),
      });
    } catch {
      // Non-fatal background sync
    }
  }, []);

  const inspectUrl = useCallback(async (url: string): Promise<UrlInspectionResult | null> => {
    const res = await fetch('/api/inspect-url', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url }),
    });
    if (!res.ok) return null;
    return (await res.json()) as UrlInspectionResult;
  }, []);

  // Auth listener + UserProfile provisioning
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setAuthReady(true);

      if (currentUser) {
        const userRef = doc(db, 'users', currentUser.uid);
        try {
          const snap = await getDoc(userRef);
          const payload = {
            uid: currentUser.uid,
            displayName: (currentUser.displayName || 'Usuário Google').slice(0, 120),
            email: (currentUser.email || '').slice(0, 200),
            photoUrl: (currentUser.photoURL || '').slice(0, 1000),
            updatedAt: serverTimestamp(),
          };
          if (!snap.exists()) {
            await setDoc(userRef, {
              ...payload,
              createdAt: serverTimestamp(),
            });
          } else {
            await updateDoc(userRef, payload);
          }
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, `users/${currentUser.uid}`);
        }
      } else {
        setApps([]);
        setSelectedAppId(null);
        setDraft(null);
        setAppsLoading(false);
      }
    });
    return () => unsubscribe();
  }, []);

  // Subscribe to user's apps
  useEffect(() => {
    if (!authReady || !user) return;
    setAppsLoading(true);
    const q = query(collection(db, 'apps'), where('ownerId', '==', user.uid));
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: AppProject[] = snapshot.docs.map((d) =>
          normalizeAppDefaults(d.data() as Partial<AppProject>)
        );
        items.sort((a, b) => {
          const tA = a.updatedAt?.toMillis?.() ?? 0;
          const tB = b.updatedAt?.toMillis?.() ?? 0;
          return tB - tA;
        });
        setApps(items);
        setAppsLoading(false);

        setSelectedAppId((prev) => {
          if (prev && items.some((item) => item.id === prev)) return prev;
          return items[0]?.id ?? null;
        });
      },
      (error) => {
        setAppsLoading(false);
        handleFirestoreError(error, OperationType.LIST, 'apps');
      }
    );

    return () => unsubscribe();
  }, [authReady, user]);

  // Sync selected app into draft when switching apps
  useEffect(() => {
    if (!selectedAppId) {
      setDraft(null);
      setHasUnsavedChanges(false);
      return;
    }
    const found = apps.find((a) => a.id === selectedAppId);
    if (found) {
      setDraft((prev) => {
        if (prev && prev.id === found.id && hasUnsavedChanges) {
          return prev;
        }
        return found;
      });
      syncRemoteConfig(found);
    }
  }, [selectedAppId, apps, hasUnsavedChanges, syncRemoteConfig]);

  // Subscribe to revisions for active app
  useEffect(() => {
    if (!authReady || !user || !selectedAppId) {
      setRevisions([]);
      return;
    }
    const revPath = `apps/${selectedAppId}/revisions`;
    const q = query(collection(db, revPath), where('ownerId', '==', user.uid));
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items = snapshot.docs.map((d) => d.data() as AppRevision);
        items.sort((a, b) => {
          const tA = a.createdAt?.toMillis?.() ?? 0;
          const tB = b.createdAt?.toMillis?.() ?? 0;
          return tB - tA;
        });
        setRevisions(items);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, revPath);
      }
    );

    return () => unsubscribe();
  }, [authReady, user, selectedAppId]);

  const persistDraftUpdate = useCallback(
    async (target: AppProject, logRevision = false, summary = 'Atualização automática salva') => {
      if (!user) return;
      setIsSaving(true);
      const cleanName = (target.name.trim() || 'Meu App').slice(0, 60);
      const cleanUrl = normalizeUrlForSave(target.websiteUrl);
      const cleanPkg = sanitizePackageName(target.packageName);
      const cleanTheme = normalizeHex(target.themeColor, '#2563EB');
      const cleanSplash = normalizeHex(target.splashBgColor, '#FFFFFF');
      const cleanIcon = target.iconUrl.slice(0, 150000);
      const cleanVersionName = (target.versionName.trim() || '1.0.0').slice(0, 20);
      const cleanVersionCode = Math.max(1, Math.min(999999, Math.round(target.versionCode || 1)));

      const appRef = doc(db, 'apps', target.id);
      const updatePayload = {
        name: cleanName,
        websiteUrl: cleanUrl,
        packageName: cleanPkg,
        iconUrl: cleanIcon,
        themeColor: cleanTheme,
        splashBgColor: cleanSplash,
        splashAnimation: target.splashAnimation || 'zoom',
        versionName: cleanVersionName,
        versionCode: cleanVersionCode,
        autoUpdateEnabled: Boolean(target.autoUpdateEnabled),
        autoSyncIcon: Boolean(target.autoSyncIcon),
        showNavBar: Boolean(target.showNavBar),
        pullToRefresh: Boolean(target.pullToRefresh),
        fullscreenMode: Boolean(target.fullscreenMode),
        lockMobileViewport: Boolean(target.lockMobileViewport),
        disableZoom: Boolean(target.disableZoom),
        openExternalApps: Boolean(target.openExternalApps),
        permCamera: Boolean(target.permCamera),
        permMicrophone: Boolean(target.permMicrophone),
        permLocation: Boolean(target.permLocation),
        permFiles: Boolean(target.permFiles),
        permBiometrics: Boolean(target.permBiometrics),
        orientation: target.orientation,
        status: target.status,
        updatedAt: serverTimestamp(),
      };

      try {
        await updateDoc(appRef, updatePayload);
        await syncRemoteConfig({
          ...target,
          name: cleanName,
          websiteUrl: cleanUrl,
          packageName: cleanPkg,
          iconUrl: cleanIcon,
          themeColor: cleanTheme,
          splashBgColor: cleanSplash,
          versionName: cleanVersionName,
          versionCode: cleanVersionCode,
        });

        if (logRevision) {
          const revId = crypto.randomUUID();
          await setDoc(doc(db, `apps/${target.id}/revisions`, revId), {
            id: revId,
            appId: target.id,
            ownerId: user.uid,
            versionName: cleanVersionName,
            versionCode: cleanVersionCode,
            changeSummary: summary.slice(0, 300),
            nameSnapshot: cleanName,
            urlSnapshot: cleanUrl,
            iconSnapshot: cleanIcon,
            exportFormat: 'config',
            createdAt: serverTimestamp(),
          });
        }

        setHasUnsavedChanges(false);
        setSaveFeedback('Sincronizado');
        window.setTimeout(() => setSaveFeedback(null), 2500);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `apps/${target.id}`);
      } finally {
        setIsSaving(false);
      }
    },
    [user, syncRemoteConfig]
  );

  // Automatic debounced sync when autoUpdateEnabled is on
  useEffect(() => {
    if (!draft || !hasUnsavedChanges || !draft.autoUpdateEnabled) return;
    if (autoSaveTimerRef.current) {
      window.clearTimeout(autoSaveTimerRef.current);
    }
    autoSaveTimerRef.current = window.setTimeout(() => {
      persistDraftUpdate(draft, false);
    }, 1000);

    return () => {
      if (autoSaveTimerRef.current) {
        window.clearTimeout(autoSaveTimerRef.current);
      }
    };
  }, [draft, hasUnsavedChanges, persistDraftUpdate]);

  async function handleGoogleLogin() {
    setIsSigningIn(true);
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Falha no login Google.';
      if (!msg.includes('popup-closed-by-user')) {
        setAuthError('Não foi possível concluir o login com Google. Tente novamente.');
      }
    } finally {
      setIsSigningIn(false);
    }
  }

  async function handleLogout() {
    await signOut(auth);
  }

  function handleDraftChange(patch: Partial<AppProject>) {
    setDraft((prev) => (prev ? { ...prev, ...patch } : prev));
    setHasUnsavedChanges(true);
  }

  async function handleInspectWebsiteInEditor(url: string): Promise<CandidateIcon[]> {
    if (!draft) return [];
    setIsInspecting(true);
    setInspectMessage(null);
    try {
      const result = await inspectUrl(url);
      if (!result) {
        setInspectMessage('Não foi possível acessar o endereço. Verifique o link informado.');
        return [];
      }

      setCandidateIcons(result.candidateIcons);

      let resolvedPngIcon = draft.iconUrl;
      if (draft.autoSyncIcon || !draft.iconUrl) {
        const rawIconSource =
          result.primaryIconUrl || result.candidateIcons[0]?.proxyUrl || '';
        if (rawIconSource) {
          try {
            const png = await imageSourceToPngDataUrl(rawIconSource, 192);
            if (png.length <= 145000) {
              resolvedPngIcon = png;
            }
          } catch {
            // Keep existing or fallback
          }
        }
      }

      const updated: AppProject = {
        ...draft,
        websiteUrl: result.websiteUrl,
        name: result.name || draft.name,
        packageName: result.packageName || draft.packageName,
        themeColor: result.themeColor || draft.themeColor,
        iconUrl: resolvedPngIcon,
      };
      setDraft(updated);
      setHasUnsavedChanges(true);

      setInspectMessage(
        result.partialNotice ||
          `Dados e ${result.candidateIcons.length} opções de ícone encontrados automaticamente.`
      );
      return result.candidateIcons;
    } catch {
      setInspectMessage('Erro ao buscar dados do site.');
      return [];
    } finally {
      setIsInspecting(false);
    }
  }

  async function handleCreateApp(e: React.FormEvent) {
    e.preventDefault();
    if (!user || !newSiteUrl.trim()) return;
    setIsCreatingApp(true);
    setCreateError(null);

    try {
      const result = await inspectUrl(newSiteUrl);
      const appId = crypto.randomUUID();
      const normalizedUrl = result?.websiteUrl || normalizeUrlForSave(newSiteUrl);
      const appName = (result?.name || 'Meu App').slice(0, 60);
      const themeColor = normalizeHex(result?.themeColor || '#2563EB');
      const pkgName = sanitizePackageName(result?.packageName || 'com.web2app.meuapp');

      let iconDataUrl = '';
      const rawSource = result?.primaryIconUrl || result?.candidateIcons[0]?.proxyUrl || '';
      if (rawSource) {
        try {
          const png = await imageSourceToPngDataUrl(rawSource, 192);
          if (png.length <= 145000) {
            iconDataUrl = png;
          }
        } catch {
          iconDataUrl = '';
        }
      }
      if (!iconDataUrl) {
        iconDataUrl = buildGeneratedFallbackIcon(appName, themeColor);
      }

      const newAppPayload = {
        id: appId,
        ownerId: user.uid,
        name: appName,
        websiteUrl: normalizedUrl,
        packageName: pkgName,
        iconUrl: iconDataUrl.slice(0, 150000),
        themeColor,
        splashBgColor: '#FFFFFF',
        splashAnimation: 'zoom' as const,
        versionName: '1.0.0',
        versionCode: 1,
        autoUpdateEnabled: true,
        autoSyncIcon: true,
        showNavBar: true,
        pullToRefresh: true,
        fullscreenMode: false,
        lockMobileViewport: true,
        disableZoom: true,
        openExternalApps: true,
        permCamera: true,
        permMicrophone: true,
        permLocation: false,
        permFiles: true,
        permBiometrics: false,
        orientation: 'portrait' as const,
        status: 'ready' as const,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };

      await setDoc(doc(db, 'apps', appId), newAppPayload);

      const revId = crypto.randomUUID();
      await setDoc(doc(db, `apps/${appId}/revisions`, revId), {
        id: revId,
        appId,
        ownerId: user.uid,
        versionName: '1.0.0',
        versionCode: 1,
        changeSummary: 'Aplicativo criado com busca automática de ícone',
        nameSnapshot: appName,
        urlSnapshot: normalizedUrl,
        iconSnapshot: iconDataUrl.slice(0, 150000),
        exportFormat: 'config',
        createdAt: serverTimestamp(),
      });

      await syncRemoteConfig({
        ...newAppPayload,
        createdAt: undefined,
        updatedAt: undefined,
      });

      if (result?.candidateIcons) {
        setCandidateIcons(result.candidateIcons);
      }

      setSelectedAppId(appId);
      setEditorTab('geral');
      setMobileTab('editor');
      setNewSiteUrl('');
      setIsCreateModalOpen(false);
    } catch (err) {
      setCreateError(
        err instanceof Error
          ? err.message
          : 'Não foi possível criar o aplicativo. Tente novamente.'
      );
    } finally {
      setIsCreatingApp(false);
    }
  }

  async function handleExport(format: ExportFormat) {
    if (!draft || !user) return;
    setExportingFormat(format);
    try {
      await persistDraftUpdate(draft, false);

      const response = await fetch('/api/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...draft,
          format,
          originUrl: window.location.origin,
        }),
      });

      if (!response.ok) {
        throw new Error('Falha ao gerar arquivo');
      }

      const blob = await response.blob();
      const disposition = response.headers.get('Content-Disposition') || '';
      const filenameMatch = disposition.match(/filename="([^"]+)"/);
      const ext = format === 'source' ? 'zip' : format;
      const filename = filenameMatch?.[1] || `web2app-${draft.versionName}.${ext}`;

      const objectUrl = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = objectUrl;
      anchor.download = filename;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(objectUrl);

      const nextCode = Math.min(999999, (draft.versionCode || 1) + 1);
      await updateDoc(doc(db, 'apps', draft.id), {
        lastExportFormat: format,
        lastExportAt: serverTimestamp(),
        status: 'published',
        versionCode: nextCode,
        updatedAt: serverTimestamp(),
      });

      const revId = crypto.randomUUID();
      await setDoc(doc(db, `apps/${draft.id}/revisions`, revId), {
        id: revId,
        appId: draft.id,
        ownerId: user.uid,
        versionName: draft.versionName,
        versionCode: nextCode,
        changeSummary: `Pacote ${format.toUpperCase()} exportado com sucesso`,
        nameSnapshot: draft.name,
        urlSnapshot: draft.websiteUrl,
        iconSnapshot: draft.iconUrl,
        exportFormat: format,
        createdAt: serverTimestamp(),
      });

      setSaveFeedback(`Exportado (${format.toUpperCase()})`);
      window.setTimeout(() => setSaveFeedback(null), 3000);
    } catch {
      setInspectMessage('Erro ao gerar o pacote. Tente novamente.');
    } finally {
      setExportingFormat(null);
    }
  }

  async function handleDeleteCurrentApp() {
    if (!draft) return;
    const idToDelete = draft.id;
    try {
      await deleteDoc(doc(db, 'apps', idToDelete));
      setSelectedAppId(null);
      setDraft(null);
      setHasUnsavedChanges(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `apps/${idToDelete}`);
    }
  }

  const filteredApps = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return apps;
    return apps.filter(
      (a) =>
        a.name.toLowerCase().includes(q) ||
        a.websiteUrl.toLowerCase().includes(q) ||
        a.packageName.toLowerCase().includes(q)
    );
  }, [apps, searchQuery]);

  const fallbackIcon = useMemo(() => {
    if (!draft) return '';
    return buildGeneratedFallbackIcon(draft.name, draft.themeColor);
  }, [draft?.name, draft?.themeColor]);

  if (!authReady) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex items-center gap-3 text-slate-600">
          <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
          <span className="text-sm font-medium">Carregando Web2App Livre...</span>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <LandingAuthView
        onGoogleLogin={handleGoogleLogin}
        isSigningIn={isSigningIn}
        authError={authError}
        onInspectPreviewUrl={inspectUrl}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      {/* Compact Sticky Top Bar */}
      <header className="sticky top-0 z-30 h-14 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 lg:px-6 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 min-w-0">
          <span className="font-display text-base sm:text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
            Web2App Livre
          </span>
          {draft && (
            <span className="hidden sm:inline text-xs text-slate-400 truncate">
              · {draft.name}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => setIsCreateModalOpen(true)}
            className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-blue-600 text-white text-xs sm:text-sm font-semibold hover:bg-blue-700 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Novo App</span>
          </button>

          <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
            {user.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || 'Avatar Google'}
                referrerPolicy="no-referrer"
                className="w-8 h-8 rounded-full border border-slate-200 object-cover"
              />
            ) : (
              <div className="w-8 h-8 rounded-full bg-slate-200 text-slate-700 text-xs font-bold flex items-center justify-center">
                {(user.displayName || user.email || 'G').charAt(0).toUpperCase()}
              </div>
            )}
            <span className="hidden md:inline text-xs font-medium text-slate-700 max-w-[140px] truncate">
              {user.displayName || user.email}
            </span>
            <button
              type="button"
              onClick={handleLogout}
              title="Sair da conta Google"
              aria-label="Sair da conta Google"
              className="min-w-[40px] min-h-[40px] rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-100 flex items-center justify-center transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Workspace */}
      <div className="flex-1 max-w-[1440px] w-full mx-auto px-4 lg:px-6 py-5 pb-24 lg:pb-8">
        {appsLoading ? (
          <div className="py-20 flex flex-col items-center justify-center text-slate-500">
            <Loader2 className="w-7 h-7 animate-spin text-blue-600 mb-3" />
            <p className="text-sm font-medium">Sincronizando seus aplicativos...</p>
          </div>
        ) : apps.length === 0 ? (
          <div className="max-w-xl mx-auto my-8 bg-white border border-slate-200 rounded-3xl p-6 sm:p-10 text-center">
            <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4">
              <Smartphone className="w-7 h-7" />
            </div>
            <h1 className="font-display text-2xl font-bold text-slate-900 mb-2">
              Crie seu primeiro aplicativo Android grátis
            </h1>
            <p className="text-sm text-slate-600 leading-relaxed mb-6">
              Cole o link de qualquer site para extrair nome e ícone automaticamente, gerenciar
              atualizações em tempo real e exportar o arquivo APK e AAB sem custo.
            </p>
            <button
              type="button"
              onClick={() => setIsCreateModalOpen(true)}
              className="min-h-[48px] px-6 py-3 rounded-xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 transition-colors inline-flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Converter Meu Primeiro Site</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* LEFT COLUMN: Apps List */}
            <aside
              className={`lg:col-span-3 space-y-3 ${
                mobileTab === 'apps' ? 'block' : 'hidden lg:block'
              }`}
            >
              <div className="bg-white border border-slate-200 rounded-2xl p-3.5">
                <div className="relative mb-3">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Buscar aplicativo..."
                    aria-label="Buscar aplicativo"
                    className="w-full min-h-[40px] pl-9 pr-3 rounded-xl border border-slate-200 bg-slate-50 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                  />
                </div>

                <div className="space-y-1.5 max-h-[540px] overflow-y-auto">
                  {filteredApps.map((item) => {
                    const isSelected = item.id === selectedAppId;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          setSelectedAppId(item.id);
                          setHasUnsavedChanges(false);
                          setCandidateIcons([]);
                          setInspectMessage(null);
                          setMobileTab('editor');
                        }}
                        className={`w-full min-h-[56px] p-2.5 rounded-xl flex items-center gap-3 text-left transition-colors cursor-pointer ${
                          isSelected
                            ? 'bg-blue-50 border border-blue-200'
                            : 'hover:bg-slate-50 border border-transparent'
                        }`}
                      >
                        <div className="w-10 h-10 rounded-xl border border-slate-200 bg-white flex items-center justify-center overflow-hidden shrink-0">
                          {item.iconUrl ? (
                            <img
                              src={item.iconUrl}
                              alt={item.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-contain p-1"
                            />
                          ) : (
                            <Smartphone className="w-5 h-5 text-slate-400" />
                          )}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-semibold text-slate-900 truncate">
                            {item.name}
                          </p>
                          <p className="text-[11px] text-slate-500 font-mono truncate">
                            v{item.versionName} · {item.packageName}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </aside>

            {/* CENTER COLUMN: Editor Panel */}
            <section
              className={`lg:col-span-5 ${
                mobileTab === 'editor' || mobileTab === 'exportar' ? 'block' : 'hidden lg:block'
              }`}
            >
              {draft && (
                <AppEditorPanel
                  draft={draft}
                  activeTab={mobileTab === 'exportar' ? 'exportar' : editorTab}
                  onTabChange={(tab) => {
                    setEditorTab(tab);
                    if (tab === 'exportar') {
                      setMobileTab('exportar');
                    } else if (mobileTab === 'exportar') {
                      setMobileTab('editor');
                    }
                  }}
                  onChange={handleDraftChange}
                  onSaveNow={() =>
                    persistDraftUpdate(draft, true, 'Atualização manual sincronizada')
                  }
                  onInspectWebsite={handleInspectWebsiteInEditor}
                  onExport={handleExport}
                  onDeleteApp={handleDeleteCurrentApp}
                  revisions={revisions}
                  candidateIcons={candidateIcons}
                  fallbackIcon={fallbackIcon}
                  isSaving={isSaving}
                  isInspecting={isInspecting}
                  exportingFormat={exportingFormat}
                  saveFeedback={saveFeedback}
                  inspectMessage={inspectMessage}
                  hasUnsavedChanges={hasUnsavedChanges}
                />
              )}
            </section>

            {/* RIGHT COLUMN: Live Android Phone Simulator */}
            <aside
              className={`lg:col-span-4 lg:sticky lg:top-20 ${
                mobileTab === 'preview' ? 'block' : 'hidden lg:block'
              }`}
            >
              {draft && <DevicePreview app={draft} fallbackIcon={fallbackIcon} />}
            </aside>
          </div>
        )}
      </div>

      {/* MOBILE BOTTOM NAVIGATION BAR */}
      {apps.length > 0 && (
        <nav
          aria-label="Navegação mobile"
          className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 pb-safe"
        >
          <div className="grid grid-cols-4 h-16 items-center">
            <button
              type="button"
              onClick={() => setMobileTab('apps')}
              className={`min-h-[44px] flex flex-col items-center justify-center gap-1 cursor-pointer ${
                mobileTab === 'apps' ? 'text-blue-600' : 'text-slate-500'
              }`}
            >
              <Layers className="w-5 h-5" />
              <span className="text-[11px] font-medium">Meus Apps</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setMobileTab('editor');
                if (editorTab === 'exportar') setEditorTab('geral');
              }}
              className={`min-h-[44px] flex flex-col items-center justify-center gap-1 cursor-pointer ${
                mobileTab === 'editor' ? 'text-blue-600' : 'text-slate-500'
              }`}
            >
              <SlidersHorizontal className="w-5 h-5" />
              <span className="text-[11px] font-medium">Editor</span>
            </button>

            <button
              type="button"
              onClick={() => setMobileTab('preview')}
              className={`min-h-[44px] flex flex-col items-center justify-center gap-1 cursor-pointer ${
                mobileTab === 'preview' ? 'text-blue-600' : 'text-slate-500'
              }`}
            >
              <Smartphone className="w-5 h-5" />
              <span className="text-[11px] font-medium">Preview</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setEditorTab('exportar');
                setMobileTab('exportar');
              }}
              className={`min-h-[44px] flex flex-col items-center justify-center gap-1 cursor-pointer ${
                mobileTab === 'exportar' ? 'text-blue-600' : 'text-slate-500'
              }`}
            >
              <Download className="w-5 h-5" />
              <span className="text-[11px] font-medium">APK/AAB</span>
            </button>
          </div>
        </nav>
      )}

      {/* CREATE NEW APP MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="w-full sm:max-w-lg bg-white rounded-t-3xl sm:rounded-2xl border border-slate-200 p-6 shadow-2xl">
            <div className="w-10 h-1.5 bg-slate-200 rounded-full mx-auto mb-4 sm:hidden" />

            <div className="flex items-center justify-between gap-4 mb-4">
              <div>
                <h2 className="font-display text-lg font-bold text-slate-900">
                  Converter Site em App Android
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  O nome e o ícone do site serão detectados automaticamente.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                aria-label="Fechar janela"
                className="min-w-[44px] min-h-[44px] rounded-xl text-slate-500 hover:bg-slate-100 flex items-center justify-center cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateApp} className="space-y-4">
              <div>
                <label
                  htmlFor="new-site-url"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Endereço do Site (URL)
                </label>
                <div className="relative">
                  <Globe className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    id="new-site-url"
                    type="text"
                    required
                    value={newSiteUrl}
                    onChange={(e) => setNewSiteUrl(e.target.value)}
                    placeholder="https://sualoja.com.br"
                    autoFocus
                    className="w-full min-h-[48px] pl-10 pr-4 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
              </div>

              {createError && (
                <p className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-xl px-3 py-2">
                  {createError}
                </p>
              )}

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="min-h-[44px] px-4 py-2 rounded-xl border border-slate-300 text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isCreatingApp}
                  className="min-h-[44px] px-5 py-2.5 rounded-xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 disabled:opacity-60 transition-colors inline-flex items-center gap-2 cursor-pointer"
                >
                  {isCreatingApp ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Plus className="w-4 h-4" />
                  )}
                  <span>{isCreatingApp ? 'Detectando dados...' : 'Criar App Grátis'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <WorkspaceApp />
    </ErrorBoundary>
  );
}
