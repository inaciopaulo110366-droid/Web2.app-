import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import zlib from 'node:zlib';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const TEMPLATE_DIR = path.resolve(__dirname, 'android-template');

export interface ApkBuildInput {
  packageName: string;
  appName: string;
  versionName: string;
  versionCode: number;
  orientation: string;
  permissions: string[];
  iconPng: Buffer;
  web2appConfigJson: string;
}

const ANDROID_NS = 'http://schemas.android.com/apk/res/android';

// Attribute resource IDs MUST stay sorted ascending in RES_XML_RESOURCE_MAP_TYPE
// and their string names MUST occupy indices 0..N-1 in the AXML StringPool.
const ATTR_RESOURCE_ENTRIES: Array<[string, number]> = [
  ['label', 0x01010001],
  ['icon', 0x01010002],
  ['name', 0x01010003],
  ['exported', 0x01010010],
  ['screenOrientation', 0x0101001e],
  ['configChanges', 0x0101001f],
  ['minSdkVersion', 0x0101020c],
  ['versionCode', 0x0101021b],
  ['versionName', 0x0101021c],
  ['targetSdkVersion', 0x01010270],
  ['allowBackup', 0x01010280],
  ['usesCleartextTraffic', 0x010104ec],
];

interface AxmlAttr {
  ns: string | null;
  name: string;
  type: number; // 0x01=ref, 0x03=string, 0x10=int_dec, 0x11=int_hex, 0x12=bool
  value: string | number;
}

interface AxmlNode {
  tag: string;
  attrs: AxmlAttr[];
  children: AxmlNode[];
}

function buildBinaryAndroidManifest(input: {
  packageName: string;
  appName: string;
  versionName: string;
  versionCode: number;
  orientation: string;
  permissions: string[];
}): Buffer {
  const orientationInt =
    input.orientation === 'portrait' ? 1 : input.orientation === 'landscape' ? 0 : -1;

  const permissionNodes: AxmlNode[] = input.permissions.map((perm) => ({
    tag: 'uses-permission',
    attrs: [{ ns: ANDROID_NS, name: 'name', type: 0x03, value: perm }],
    children: [],
  }));

  const root: AxmlNode = {
    tag: 'manifest',
    attrs: [
      { ns: ANDROID_NS, name: 'versionCode', type: 0x10, value: input.versionCode },
      { ns: ANDROID_NS, name: 'versionName', type: 0x03, value: input.versionName },
      { ns: null, name: 'package', type: 0x03, value: input.packageName },
    ],
    children: [
      {
        tag: 'uses-sdk',
        attrs: [
          { ns: ANDROID_NS, name: 'minSdkVersion', type: 0x10, value: 23 },
          { ns: ANDROID_NS, name: 'targetSdkVersion', type: 0x10, value: 34 },
        ],
        children: [],
      },
      ...permissionNodes,
      {
        tag: 'application',
        attrs: [
          { ns: ANDROID_NS, name: 'label', type: 0x03, value: input.appName },
          { ns: ANDROID_NS, name: 'icon', type: 0x01, value: 0x7f020000 },
          { ns: ANDROID_NS, name: 'allowBackup', type: 0x12, value: 0xffffffff },
          { ns: ANDROID_NS, name: 'usesCleartextTraffic', type: 0x12, value: 0xffffffff },
        ],
        children: [
          {
            tag: 'activity',
            attrs: [
              { ns: ANDROID_NS, name: 'label', type: 0x03, value: input.appName },
              { ns: ANDROID_NS, name: 'name', type: 0x03, value: 'com.web2app.runtime.MainActivity' },
              { ns: ANDROID_NS, name: 'exported', type: 0x12, value: 0xffffffff },
              { ns: ANDROID_NS, name: 'screenOrientation', type: 0x10, value: orientationInt },
              { ns: ANDROID_NS, name: 'configChanges', type: 0x11, value: 0x4a0 },
            ],
            children: [
              {
                tag: 'intent-filter',
                attrs: [],
                children: [
                  {
                    tag: 'action',
                    attrs: [
                      { ns: ANDROID_NS, name: 'name', type: 0x03, value: 'android.intent.action.MAIN' },
                    ],
                    children: [],
                  },
                  {
                    tag: 'category',
                    attrs: [
                      {
                        ns: ANDROID_NS,
                        name: 'name',
                        type: 0x03,
                        value: 'android.intent.category.LAUNCHER',
                      },
                    ],
                    children: [],
                  },
                ],
              },
            ],
          },
        ],
      },
    ],
  };

  // Build StringPool: first ATTR_RESOURCE_ENTRIES in exact order, then all other unique strings
  const strings: string[] = [];
  const stringMap = new Map<string, number>();

  function intern(s: string): number {
    const existing = stringMap.get(s);
    if (existing !== undefined) return existing;
    const idx = strings.length;
    strings.push(s);
    stringMap.set(s, idx);
    return idx;
  }

  for (const [attrName] of ATTR_RESOURCE_ENTRIES) {
    intern(attrName);
  }
  intern('android');
  intern(ANDROID_NS);

  function collectStrings(node: AxmlNode) {
    intern(node.tag);
    for (const a of node.attrs) {
      if (a.ns) intern(a.ns);
      intern(a.name);
      if (a.type === 0x03) {
        intern(String(a.value));
      }
    }
    for (const child of node.children) {
      collectStrings(child);
    }
  }
  collectStrings(root);

  // Encode StringPool (UTF-16LE)
  const stringBuffers: Buffer[] = [];
  const stringOffsets: number[] = [];
  let currentOffset = 0;
  for (const s of strings) {
    stringOffsets.push(currentOffset);
    const charLen = s.length;
    const utf16 = Buffer.from(s, 'utf16le');
    const entry = Buffer.alloc(2 + utf16.length + 2);
    entry.writeUInt16LE(charLen, 0);
    utf16.copy(entry, 2);
    entry.writeUInt16LE(0, 2 + utf16.length);
    stringBuffers.push(entry);
    currentOffset += entry.length;
  }
  const rawStringBytes = Buffer.concat(stringBuffers);
  const padLen = (4 - (rawStringBytes.length % 4)) % 4;
  const paddedStringBytes = Buffer.concat([rawStringBytes, Buffer.alloc(padLen)]);

  const stringPoolHeaderSize = 28;
  const offsetsTableSize = strings.length * 4;
  const stringsStart = stringPoolHeaderSize + offsetsTableSize;
  const stringPoolSize = stringsStart + paddedStringBytes.length;

  const stringPoolChunk = Buffer.alloc(stringPoolSize);
  stringPoolChunk.writeUInt16LE(0x0001, 0); // RES_STRING_POOL_TYPE
  stringPoolChunk.writeUInt16LE(stringPoolHeaderSize, 2);
  stringPoolChunk.writeUInt32LE(stringPoolSize, 4);
  stringPoolChunk.writeUInt32LE(strings.length, 8);
  stringPoolChunk.writeUInt32LE(0, 12); // styleCount
  stringPoolChunk.writeUInt32LE(0, 16); // flags (UTF-16)
  stringPoolChunk.writeUInt32LE(stringsStart, 20);
  stringPoolChunk.writeUInt32LE(0, 24); // stylesStart
  for (let i = 0; i < stringOffsets.length; i++) {
    stringPoolChunk.writeUInt32LE(stringOffsets[i], 28 + i * 4);
  }
  paddedStringBytes.copy(stringPoolChunk, stringsStart);

  // Encode ResourceMap chunk
  const resMapSize = 8 + ATTR_RESOURCE_ENTRIES.length * 4;
  const resMapChunk = Buffer.alloc(resMapSize);
  resMapChunk.writeUInt16LE(0x0180, 0); // RES_XML_RESOURCE_MAP_TYPE
  resMapChunk.writeUInt16LE(8, 2);
  resMapChunk.writeUInt32LE(resMapSize, 4);
  for (let i = 0; i < ATTR_RESOURCE_ENTRIES.length; i++) {
    resMapChunk.writeUInt32LE(ATTR_RESOURCE_ENTRIES[i][1], 8 + i * 4);
  }

  const xmlChunks: Buffer[] = [];
  let lineNo = 2;

  // Start Namespace
  const startNs = Buffer.alloc(24);
  startNs.writeUInt16LE(0x0100, 0); // RES_XML_START_NAMESPACE_TYPE
  startNs.writeUInt16LE(16, 2);
  startNs.writeUInt32LE(24, 4);
  startNs.writeUInt32LE(1, 8);
  startNs.writeInt32LE(-1, 12);
  startNs.writeUInt32LE(intern('android'), 16);
  startNs.writeUInt32LE(intern(ANDROID_NS), 20);
  xmlChunks.push(startNs);

  function emitNode(node: AxmlNode) {
    const currentLine = lineNo++;
    const attrCount = node.attrs.length;
    const elemSize = 36 + attrCount * 20;
    const startElem = Buffer.alloc(elemSize);
    startElem.writeUInt16LE(0x0102, 0); // RES_XML_START_ELEMENT_TYPE
    startElem.writeUInt16LE(16, 2);
    startElem.writeUInt32LE(elemSize, 4);
    startElem.writeUInt32LE(currentLine, 8);
    startElem.writeInt32LE(-1, 12);
    startElem.writeInt32LE(-1, 16); // ns
    startElem.writeUInt32LE(intern(node.tag), 20);
    startElem.writeUInt16LE(0x0014, 24); // attributeStart
    startElem.writeUInt16LE(0x0014, 26); // attributeSize
    startElem.writeUInt16LE(attrCount, 28);
    startElem.writeUInt16LE(0, 30); // idIndex
    startElem.writeUInt16LE(0, 32); // classIndex
    startElem.writeUInt16LE(0, 34); // styleIndex

    for (let i = 0; i < attrCount; i++) {
      const a = node.attrs[i];
      const base = 36 + i * 20;
      startElem.writeInt32LE(a.ns ? intern(a.ns) : -1, base);
      startElem.writeUInt32LE(intern(a.name), base + 4);
      if (a.type === 0x03) {
        const strIdx = intern(String(a.value));
        startElem.writeInt32LE(strIdx, base + 8);
        startElem.writeUInt16LE(8, base + 12); // Res_value.size
        startElem.writeUInt8(0, base + 14);
        startElem.writeUInt8(0x03, base + 15);
        startElem.writeInt32LE(strIdx, base + 16);
      } else {
        startElem.writeInt32LE(-1, base + 8);
        startElem.writeUInt16LE(8, base + 12);
        startElem.writeUInt8(0, base + 14);
        startElem.writeUInt8(a.type, base + 15);
        startElem.writeInt32LE(Number(a.value) | 0, base + 16);
      }
    }
    xmlChunks.push(startElem);

    for (const child of node.children) {
      emitNode(child);
    }

    const endElem = Buffer.alloc(24);
    endElem.writeUInt16LE(0x0103, 0); // RES_XML_END_ELEMENT_TYPE
    endElem.writeUInt16LE(16, 2);
    endElem.writeUInt32LE(24, 4);
    endElem.writeUInt32LE(lineNo, 8);
    endElem.writeInt32LE(-1, 12);
    endElem.writeInt32LE(-1, 16);
    endElem.writeUInt32LE(intern(node.tag), 20);
    xmlChunks.push(endElem);
  }

  emitNode(root);

  const endNs = Buffer.alloc(24);
  endNs.writeUInt16LE(0x0101, 0); // RES_XML_END_NAMESPACE_TYPE
  endNs.writeUInt16LE(16, 2);
  endNs.writeUInt32LE(24, 4);
  endNs.writeUInt32LE(lineNo, 8);
  endNs.writeInt32LE(-1, 12);
  endNs.writeUInt32LE(intern('android'), 16);
  endNs.writeUInt32LE(intern(ANDROID_NS), 20);
  xmlChunks.push(endNs);

  const body = Buffer.concat([stringPoolChunk, resMapChunk, ...xmlChunks]);
  const header = Buffer.alloc(8);
  header.writeUInt16LE(0x0003, 0); // RES_XML_TYPE
  header.writeUInt16LE(8, 2);
  header.writeUInt32LE(8 + body.length, 4);

  return Buffer.concat([header, body]);
}

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) {
      c = (c >>> 1) ^ (c & 1 ? 0xedb88320 : 0);
    }
  }
  return (c ^ 0xffffffff) >>> 0;
}

// ASN.1 DER minimal helpers for PKCS#7 v1 JAR signature (META-INF/CERT.RSA)
function derLength(len: number): Buffer {
  if (len < 0x80) return Buffer.from([len]);
  const bytes: number[] = [];
  let n = len;
  while (n > 0) {
    bytes.unshift(n & 0xff);
    n >>>= 8;
  }
  return Buffer.from([0x80 | bytes.length, ...bytes]);
}

function derTag(tag: number, content: Buffer): Buffer {
  return Buffer.concat([Buffer.from([tag]), derLength(content.length), content]);
}

function derSeq(...items: Buffer[]): Buffer {
  return derTag(0x30, Buffer.concat(items));
}

function derSet(...items: Buffer[]): Buffer {
  return derTag(0x31, Buffer.concat(items));
}

function derOid(oidBytes: number[]): Buffer {
  return derTag(0x06, Buffer.from(oidBytes));
}

function derInt(val: number | Buffer): Buffer {
  if (typeof val === 'number') {
    return derTag(0x02, Buffer.from([val]));
  }
  return derTag(0x02, val);
}

// Parse Issuer and SerialNumber straight from X.509 DER certificate
function extractX509IssuerAndSerial(certDer: Buffer): { issuer: Buffer; serial: Buffer } {
  // Certificate ::= SEQUENCE { tbsCertificate SEQUENCE, ... }
  function readTlv(buf: Buffer, offset: number) {
    const tag = buf[offset];
    let lenByte = buf[offset + 1];
    let headerLen = 2;
    let len = lenByte;
    if (lenByte & 0x80) {
      const count = lenByte & 0x7f;
      len = 0;
      for (let i = 0; i < count; i++) {
        len = (len << 8) | buf[offset + 2 + i];
      }
      headerLen = 2 + count;
    }
    return {
      tag,
      start: offset,
      contentStart: offset + headerLen,
      end: offset + headerLen + len,
      raw: buf.subarray(offset, offset + headerLen + len),
    };
  }

  const certSeq = readTlv(certDer, 0);
  const tbsSeq = readTlv(certDer, certSeq.contentStart);
  let pos = tbsSeq.contentStart;
  const first = readTlv(certDer, pos);
  if (first.tag === 0xa0) {
    pos = first.end; // skip explicit [0] version
  }
  const serial = readTlv(certDer, pos);
  pos = serial.end;
  const sigAlg = readTlv(certDer, pos);
  pos = sigAlg.end;
  const issuer = readTlv(certDer, pos);
  return { issuer: issuer.raw, serial: serial.raw };
}

function buildPkcs7CertRsa(certSfBytes: Buffer, certDer: Buffer, privateKeyPem: string): Buffer {
  const { issuer, serial } = extractX509IssuerAndSerial(certDer);
  const signature = crypto.sign('RSA-SHA256', certSfBytes, privateKeyPem);

  // OIDs
  const oidSignedData = derOid([0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x07, 0x02]); // 1.2.840.113549.1.7.2
  const oidData = derOid([0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x07, 0x01]); // 1.2.840.113549.1.7.1
  const oidSha256 = derOid([0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01]); // 2.16.840.1.101.3.4.2.1
  const oidRsa = derOid([0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x01]); // 1.2.840.113549.1.1.1
  const derNull = Buffer.from([0x05, 0x00]);

  const sha256AlgId = derSeq(oidSha256, derNull);
  const rsaAlgId = derSeq(oidRsa, derNull);

  const signerInfo = derSeq(
    derInt(1),
    derSeq(issuer, serial),
    sha256AlgId,
    rsaAlgId,
    derTag(0x04, signature)
  );

  const signedData = derSeq(
    derInt(1),
    derSet(sha256AlgId),
    derSeq(oidData),
    derTag(0xa0, certDer),
    derSet(signerInfo)
  );

  return derSeq(oidSignedData, derTag(0xa0, signedData));
}

function buildJarManifestAndSf(
  entries: Array<{ name: string; data: Buffer }>,
  certDer: Buffer,
  privateKeyPem: string
): Array<{ name: string; data: Buffer; store: boolean }> {
  const mfLines = ['Manifest-Version: 1.0', 'Created-By: Web2App Livre Builder', ''];
  const sfEntries: string[] = [];

  for (const entry of entries) {
    const digest = crypto.createHash('sha256').update(entry.data).digest('base64');
    const block = `Name: ${entry.name}\r\nSHA-256-Digest: ${digest}\r\n\r\n`;
    mfLines.push(`Name: ${entry.name}`, `SHA-256-Digest: ${digest}`, '');
    const blockHash = crypto
      .createHash('sha256')
      .update(Buffer.from(block, 'utf-8'))
      .digest('base64');
    sfEntries.push(`Name: ${entry.name}\r\nSHA-256-Digest: ${blockHash}\r\n\r\n`);
  }

  const mfBuf = Buffer.from(mfLines.join('\r\n'), 'utf-8');
  const mfHash = crypto.createHash('sha256').update(mfBuf).digest('base64');
  const sfHeader =
    `Signature-Version: 1.0\r\n` +
    `Created-By: Web2App Livre Builder\r\n` +
    `SHA-256-Digest-Manifest: ${mfHash}\r\n` +
    `X-Android-APK-Signed: 2\r\n\r\n`;
  const sfBuf = Buffer.from(sfHeader + sfEntries.join(''), 'utf-8');
  const certRsaBuf = buildPkcs7CertRsa(sfBuf, certDer, privateKeyPem);

  return [
    { name: 'META-INF/MANIFEST.MF', data: mfBuf, store: false },
    { name: 'META-INF/CERT.SF', data: sfBuf, store: false },
    { name: 'META-INF/CERT.RSA', data: certRsaBuf, store: false },
  ];
}

// Compute APK Signature Scheme v2 chunked SHA-256 digest over ZIP sections
function computeApkV2Digest(section1: Buffer, section3: Buffer, section4Eocd: Buffer): Buffer {
  const CHUNK_SIZE = 1024 * 1024;
  const chunkDigests: Buffer[] = [];

  for (const section of [section1, section3, section4Eocd]) {
    let offset = 0;
    if (section.length === 0) {
      const prefix = Buffer.alloc(5);
      prefix[0] = 0xa5;
      prefix.writeUInt32LE(0, 1);
      chunkDigests.push(crypto.createHash('sha256').update(prefix).digest());
      continue;
    }
    while (offset < section.length) {
      const end = Math.min(offset + CHUNK_SIZE, section.length);
      const chunk = section.subarray(offset, end);
      const prefix = Buffer.alloc(5);
      prefix[0] = 0xa5;
      prefix.writeUInt32LE(chunk.length, 1);
      const h = crypto.createHash('sha256');
      h.update(prefix);
      h.update(chunk);
      chunkDigests.push(h.digest());
      offset = end;
    }
  }

  const topPrefix = Buffer.alloc(5);
  topPrefix[0] = 0x5a;
  topPrefix.writeUInt32LE(chunkDigests.length, 1);
  const finalHash = crypto.createHash('sha256');
  finalHash.update(topPrefix);
  for (const d of chunkDigests) {
    finalHash.update(d);
  }
  return finalHash.digest();
}

function lenPrefixed(buf: Buffer): Buffer {
  const len = Buffer.alloc(4);
  len.writeUInt32LE(buf.length, 0);
  return Buffer.concat([len, buf]);
}

function buildApkSigningBlockV2(
  entriesSection: Buffer,
  centralDir: Buffer,
  eocdTemplate: Buffer,
  certDer: Buffer,
  privateKeyPem: string
): { signingBlock: Buffer; patchedEocd: Buffer } {
  // First compute the exact block size so we know cdOffset = entriesSection.length + signingBlock.length
  // We compute digest twice or pre-calculate exact length? Wait: APK v2 digest hashes EOCD with cdOffset pointing to final CD offset!
  // Let's construct signedData structure cleanly (RSA-2048 signature is always 256 bytes!).
  const dummyDigest = Buffer.alloc(32);
  const sigAlgId = 0x0103; // RSASSA-PKCS1-v1_5 with SHA-256

  function assembleBlock(actualCdOffset: number, sigBytes: Buffer, digestBytes: Buffer): Buffer {
    const digestEntry = lenPrefixed(
      Buffer.concat([
        (() => {
          const b = Buffer.alloc(4);
          b.writeUInt32LE(sigAlgId, 0);
          return b;
        })(),
        lenPrefixed(digestBytes),
      ])
    );
    const digests = lenPrefixed(digestEntry);
    const certs = lenPrefixed(lenPrefixed(certDer));
    const additionalAttrs = lenPrefixed(Buffer.alloc(0));
    const signedData = Buffer.concat([digests, certs, additionalAttrs]);

    const sigEntry = lenPrefixed(
      Buffer.concat([
        (() => {
          const b = Buffer.alloc(4);
          b.writeUInt32LE(sigAlgId, 0);
          return b;
        })(),
        lenPrefixed(sigBytes),
      ])
    );
    const signatures = lenPrefixed(sigEntry);

    const publicKeyDer = crypto
      .createPublicKey(certDer ? { key: crypto.X509Certificate ? new crypto.X509Certificate(certDer).publicKey.export({ type: 'spki', format: 'der' }) : Buffer.alloc(0), format: 'der', type: 'spki' } : privateKeyPem)
      .export({ type: 'spki', format: 'der' }) as Buffer;

    const signer = lenPrefixed(
      Buffer.concat([lenPrefixed(signedData), signatures, lenPrefixed(publicKeyDer)])
    );
    const signers = lenPrefixed(signer);
    const v2SchemeValue = signers;

    // Pair: [uint64 pairSize][uint32 id=0x7109871a][v2SchemeValue]
    const pairBody = Buffer.concat([
      (() => {
        const b = Buffer.alloc(4);
        b.writeUInt32LE(0x7109871a, 0);
        return b;
      })(),
      v2SchemeValue,
    ]);
    const pairLen = Buffer.alloc(8);
    pairLen.writeBigUInt64LE(BigInt(pairBody.length), 0);

    // Pad block to 4096-byte boundary or keep clean 8+pairs+8+16
    const rawPairs = Buffer.concat([pairLen, pairBody]);
    const blockSizeAfterHeader = rawPairs.length + 8 + 16; // + footer sizeOfBlock (8) + magic (16)
    const sizeOfBlockBuf = Buffer.alloc(8);
    sizeOfBlockBuf.writeBigUInt64LE(BigInt(blockSizeAfterHeader), 0);

    const magic = Buffer.from('APK Sig Block 42', 'ascii');
    return Buffer.concat([sizeOfBlockBuf, rawPairs, sizeOfBlockBuf, magic]);
  }

  // Pass 1: measure exact signingBlock length using dummy 256-byte RSA-2048 signature
  const dummyBlock = assembleBlock(entriesSection.length, Buffer.alloc(256), dummyDigest);
  const finalCdOffset = entriesSection.length + dummyBlock.length;

  const patchedEocd = Buffer.from(eocdTemplate);
  patchedEocd.writeUInt32LE(finalCdOffset, 16);

  // Pass 2: compute real v2 chunked SHA-256 digest over (entriesSection, centralDir, eocdTemplate where cdOffset = start of APK Signing Block)
  const realDigest = computeApkV2Digest(entriesSection, centralDir, eocdTemplate);

  // Build exact signedData bytes to sign with RSA-2048 private key
  const digestEntry = lenPrefixed(
    Buffer.concat([
      (() => {
        const b = Buffer.alloc(4);
        b.writeUInt32LE(sigAlgId, 0);
        return b;
      })(),
      lenPrefixed(realDigest),
    ])
  );
  const signedDataToSign = Buffer.concat([
    lenPrefixed(digestEntry),
    lenPrefixed(lenPrefixed(certDer)),
    lenPrefixed(Buffer.alloc(0)),
  ]);
  const realSig = crypto.sign('RSA-SHA256', signedDataToSign, privateKeyPem);
  const signingBlock = assembleBlock(finalCdOffset, realSig, realDigest);

  return { signingBlock, patchedEocd };
}

export function buildSignedAndroidApk(input: ApkBuildInput): Buffer {
  const classesDex = fs.readFileSync(path.join(TEMPLATE_DIR, 'classes.dex'));
  const resourcesArsc = fs.readFileSync(path.join(TEMPLATE_DIR, 'resources.arsc'));
  const certDer = fs.readFileSync(path.join(TEMPLATE_DIR, 'signing-cert.der'));
  const privateKeyPem = fs.readFileSync(path.join(TEMPLATE_DIR, 'signing-key.pem'), 'utf-8');

  const manifestBin = buildBinaryAndroidManifest({
    packageName: input.packageName,
    appName: input.appName,
    versionName: input.versionName,
    versionCode: input.versionCode,
    orientation: input.orientation,
    permissions: input.permissions,
  });

  const baseEntries: Array<{ name: string; data: Buffer; store: boolean }> = [
    { name: 'AndroidManifest.xml', data: manifestBin, store: false },
    { name: 'classes.dex', data: classesDex, store: false },
    { name: 'resources.arsc', data: resourcesArsc, store: true }, // Must be uncompressed & 4-byte aligned on Android 11+
    {
      name: 'assets/web2app_config.json',
      data: Buffer.from(input.web2appConfigJson, 'utf-8'),
      store: false,
    },
    { name: 'res/mipmap-mdpi-v4/ic_launcher.png', data: input.iconPng, store: true },
    { name: 'res/mipmap-hdpi-v4/ic_launcher.png', data: input.iconPng, store: true },
    { name: 'res/mipmap-xhdpi-v4/ic_launcher.png', data: input.iconPng, store: true },
    { name: 'res/mipmap-xxhdpi-v4/ic_launcher.png', data: input.iconPng, store: true },
    { name: 'res/mipmap-xxxhdpi-v4/ic_launcher.png', data: input.iconPng, store: true },
  ];

  const metaInfEntries = buildJarManifestAndSf(baseEntries, certDer, privateKeyPem);
  const allEntries = [...baseEntries, ...metaInfEntries];

  // Assemble zipaligned ZIP entries + Central Directory
  const localParts: Buffer[] = [];
  const cdParts: Buffer[] = [];
  let offset = 0;

  for (const entry of allEntries) {
    const nameBuf = Buffer.from(entry.name, 'utf-8');
    const crc = crc32(entry.data);
    const compressed = entry.store ? entry.data : zlib.deflateRawSync(entry.data);
    const method = entry.store ? 0 : 8;

    // 4-byte alignment for stored (uncompressed) entries like resources.arsc and PNGs
    const headerBaseLen = 30 + nameBuf.length;
    const alignPad = entry.store ? (4 - ((offset + headerBaseLen) % 4)) % 4 : 0;
    const extraBuf = Buffer.alloc(alignPad);

    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0);
    localHeader.writeUInt16LE(20, 4); // version needed
    localHeader.writeUInt16LE(0x0800, 6); // UTF-8 filename flag
    localHeader.writeUInt16LE(method, 8);
    localHeader.writeUInt16LE(0, 10); // mod time
    localHeader.writeUInt16LE(0x5421, 12); // mod date
    localHeader.writeUInt32LE(crc, 14);
    localHeader.writeUInt32LE(compressed.length, 18);
    localHeader.writeUInt32LE(entry.data.length, 22);
    localHeader.writeUInt16LE(nameBuf.length, 26);
    localHeader.writeUInt16LE(extraBuf.length, 28);

    const cdHeader = Buffer.alloc(46);
    cdHeader.writeUInt32LE(0x02014b50, 0);
    cdHeader.writeUInt16LE(20, 4); // version made by
    cdHeader.writeUInt16LE(20, 6); // version needed
    cdHeader.writeUInt16LE(0x0800, 8); // UTF-8 flag
    cdHeader.writeUInt16LE(method, 10);
    cdHeader.writeUInt16LE(0, 12);
    cdHeader.writeUInt16LE(0x5421, 14);
    cdHeader.writeUInt32LE(crc, 16);
    cdHeader.writeUInt32LE(compressed.length, 20);
    cdHeader.writeUInt32LE(entry.data.length, 24);
    cdHeader.writeUInt16LE(nameBuf.length, 28);
    cdHeader.writeUInt16LE(0, 30); // extra len
    cdHeader.writeUInt16LE(0, 32); // comment len
    cdHeader.writeUInt16LE(0, 34); // disk start
    cdHeader.writeUInt16LE(0, 36); // internal attrs
    cdHeader.writeUInt32LE(0, 38); // external attrs
    cdHeader.writeUInt32LE(offset, 42); // local header offset

    localParts.push(localHeader, nameBuf, extraBuf, compressed);
    cdParts.push(cdHeader, nameBuf);

    offset += localHeader.length + nameBuf.length + extraBuf.length + compressed.length;
  }

  const entriesSection = Buffer.concat(localParts);
  const centralDir = Buffer.concat(cdParts);

  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(allEntries.length, 8);
  eocd.writeUInt16LE(allEntries.length, 10);
  eocd.writeUInt32LE(centralDir.length, 12);
  eocd.writeUInt32LE(entriesSection.length, 16);
  eocd.writeUInt16LE(0, 20);

  const { signingBlock, patchedEocd } = buildApkSigningBlockV2(
    entriesSection,
    centralDir,
    eocd,
    certDer,
    privateKeyPem
  );

  return Buffer.concat([entriesSection, signingBlock, centralDir, patchedEocd]);
}
