/**
 * Converts any image file or URL into a crisp 192x192 PNG Data URL
 * suitable for Firestore storage (<= 150KB) and Android ic_launcher.png packaging.
 */
export async function imageSourceToPngDataUrl(src: string, size = 192): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas context unavailable'));
          return;
        }
        ctx.clearRect(0, 0, size, size);
        // Fit image preserving aspect ratio inside square
        const scale = Math.min(size / img.width, size / img.height);
        const drawW = img.width * scale;
        const drawH = img.height * scale;
        const offsetX = (size - drawW) / 2;
        const offsetY = (size - drawH) / 2;
        ctx.drawImage(img, offsetX, offsetY, drawW, drawH);
        const dataUrl = canvas.toDataURL('image/png');
        resolve(dataUrl);
      } catch (err) {
        reject(err);
      }
    };
    img.onerror = () => reject(new Error('Falha ao carregar imagem do ícone'));
    img.src = src;
  });
}

export async function fileToPngDataUrl(file: File): Promise<string> {
  const readerUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('Falha ao ler arquivo selecionado'));
    reader.readAsDataURL(file);
  });
  return imageSourceToPngDataUrl(readerUrl, 192);
}

export function buildGeneratedFallbackIcon(name: string, themeColor: string): string {
  const letter = (name.trim().charAt(0) || 'A').toUpperCase();
  const canvas = document.createElement('canvas');
  canvas.width = 192;
  canvas.height = 192;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  ctx.fillStyle = themeColor || '#2563EB';
  ctx.beginPath();
  ctx.roundRect(0, 0, 192, 192, 42);
  ctx.fill();

  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 88px "Plus Jakarta Sans", system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(letter, 96, 100);

  return canvas.toDataURL('image/png');
}

export function sanitizePackageName(raw: string): string {
  const cleaned = raw
    .toLowerCase()
    .replace(/[^a-z0-9.]/g, '')
    .replace(/\.+/g, '.')
    .replace(/^\.|\.$/g, '');
  const parts = cleaned
    .split('.')
    .filter(Boolean)
    .map((segment) => (/^[a-z]/.test(segment) ? segment : `app${segment}`));

  if (parts.length < 2) {
    return `com.web2app.${parts[0] || 'meuapp'}`;
  }
  return parts.join('.').slice(0, 120);
}
